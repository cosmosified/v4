# INSTALLATION INSTRUCTIONS

Installation instruction has moved to [http://docs.mailwatch.org](http://docs.mailwatch.org)
